import importlib.util,pathlib
P=pathlib.Path(__file__).with_name('meridian_finance.py')
spec=importlib.util.spec_from_file_location('tool',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def test_correct_metrics():
    x=m.financial_metrics()['metrics']
    assert x['comparison']['revenue_growth_pct']==15.0
    assert x['comparison']['net_profit_change_pct']==-28.846
    assert x['2025']['current_ratio']==1.494
    assert 31.99<x['2025']['gross_margin_pct']<32.01
def test_eight_cases():
    assert m.check()['passed']
def test_no_payment():
    assert all(r['payment_authorized'] is False for r in m.invoice_results()['results'])
def test_human_review():
    assert all(r['human_approval_required'] for r in m.invoice_results()['results'])
def test_order_of_rules():
    r=m.triage({'invoice_id':'X','supplier':'ALPHA','invoice_ref':'A-776','amount_usd':'20000','po_id':'','bank_changed':'YES'})
    assert r['status']=='HOLD_DUPLICATE' and 'HIGH_VALUE' in r['control_flags']
def test_po_supplier():
    r=m.triage({'invoice_id':'X','supplier':'GAMMA','invoice_ref':'GG-1','amount_usd':'1250','po_id':'PO-501','bank_changed':'NO'})
    assert r['status']=='REVIEW_PO_SUPPLIER'
def test_invalid_amount():
    r=m.triage({'invoice_id':'X','supplier':'A','invoice_ref':'Z','amount_usd':'abc','po_id':'PO-501'})
    assert r['status']=='HOLD_INVALID_DATA'
def test_threshold_strict():
    r=m.triage({'invoice_id':'X','supplier':'DELTA','invoice_ref':'D-2','amount_usd':'10000','po_id':'PO-505'})
    assert r['manager_approval_required'] is False
def test_synthetic_provenance():
    r=m.triage({'invoice_id':'X','supplier':'ALPHA','invoice_ref':'A-777','amount_usd':'1250','po_id':'PO-501'})
    assert 'data/purchase_orders.csv' in r['sources']
