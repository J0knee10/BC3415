#!/usr/bin/env python3
"""Offline, read-only synthetic finance toolkit for teaching Hermes Agent.
No model calls, network, payments, writes outside explicit --output file.
"""
from __future__ import annotations
import argparse, csv, json, pathlib, sys, datetime, collections
BASE = pathlib.Path(__file__).resolve().parents[1]
DATA = BASE / 'data'


def load(name):
    with (DATA/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def financial_metrics():
    rows=load('meridian_financials.csv')
    by={(r['statement'],r['metric']):r for r in rows}
    def v(stmt, metric, year): return float(by[(stmt,metric)][str(year)])
    metrics={}
    for y in (2024,2025):
        current=v('balance','cash',y)+v('balance','receivables',y)+v('balance','inventory',y)+v('balance','other_current_assets',y)
        liabilities=v('balance','accounts_payable',y)+v('balance','short_debt',y)+v('balance','other_current_liabilities',y)
        metrics[str(y)]={
            'revenue_usd_000':v('income','revenue',y),
            'net_profit_usd_000':v('income','net_profit',y),
            'gross_margin_pct':round(100*v('income','gross_profit',y)/v('income','revenue',y),3),
            'operating_margin_pct':round(100*v('income','operating_profit',y)/v('income','revenue',y),3),
            'net_margin_pct':round(100*v('income','net_profit',y)/v('income','revenue',y),3),
            'current_ratio':round(current/liabilities,4),
            'quick_ratio_cash_plus_receivables':round((v('balance','cash',y)+v('balance','receivables',y))/liabilities,4),
            'cash_usd_000':v('balance','cash',y),
            'receivables_usd_000':v('balance','receivables',y),
            'inventory_usd_000':v('balance','inventory',y)
        }
    metrics['comparison']={
        'revenue_growth_pct':round(100*(metrics['2025']['revenue_usd_000']/metrics['2024']['revenue_usd_000']-1),3),
        'net_profit_change_pct':round(100*(metrics['2025']['net_profit_usd_000']/metrics['2024']['net_profit_usd_000']-1),3),
        'gross_margin_change_pp':round(metrics['2025']['gross_margin_pct']-metrics['2024']['gross_margin_pct'],3),
        'receivables_change_usd_000':round(metrics['2025']['receivables_usd_000']-metrics['2024']['receivables_usd_000'],2)
    }
    return {'company':'Meridian Retail & Services (FICTIONAL)','source_file':'data/meridian_financials.csv','units':'USD thousands unless percent or ratio','metrics':metrics}

def triage(invoice):
    required=['invoice_id','supplier','invoice_ref','amount_usd']
    po={r['po_id']:{'supplier':r['supplier'].upper(),'amount':float(r['po_amount_usd'])} for r in load('purchase_orders.csv')}
    posted={(r['supplier'].upper(),r['invoice_ref'].upper()) for r in load('posted_invoice_history.csv')}
    inv={k:str(invoice.get(k,'')).strip() for k in ['team_id','invoice_id','supplier','invoice_ref','amount_usd','po_id','bank_changed']}
    supplier=inv['supplier'].upper(); ref=inv['invoice_ref'].upper(); po_id=inv['po_id'].upper()
    bank_changed=inv['bank_changed'].upper() in {'YES','TRUE','1'}
    try: amount=float(inv['amount_usd']); valid_amount=0<amount<1e7
    except (ValueError,TypeError): amount=None; valid_amount=False
    manager= bool(valid_amount and amount>10000)
    flags=[]; status='READY_FOR_HUMAN_CHECK'; reason='Rules passed; human confirmation still required'
    if not inv['invoice_id'] or not supplier or not ref or not valid_amount:
        status='HOLD_INVALID_DATA';reason='Required field missing or invalid amount';flags.append('INVALID_DATA')
    elif (supplier,ref) in posted:
        status='HOLD_DUPLICATE';reason='Supplier and reference already in synthetic historic ledger';flags.append('HISTORIC_DUPLICATE')
    elif bank_changed:
        status='HOLD_BANK_CHANGE';reason='Bank details changed; independent verification required';flags.append('BANK_CHANGE')
    elif not po_id:
        status='REVIEW_MISSING_PO';reason='Purchase order missing';flags.append('MISSING_PO')
    elif po_id not in po:
        status='REVIEW_UNKNOWN_PO';reason='PO ID not in the approved synthetic PO master';flags.append('UNKNOWN_PO')
    elif po[po_id]['supplier']!=supplier:
        status='REVIEW_PO_SUPPLIER';reason='Supplier does not match the PO master';flags.append('PO_SUPPLIER_MISMATCH')
    elif abs(po[po_id]['amount']-amount)>0.01:
        status='REVIEW_AMOUNT_MISMATCH';reason=f"PO amount is ${po[po_id]['amount']:.2f}, not the invoice amount";flags.append('AMOUNT_MISMATCH')
    elif manager:
        status='REVIEW_MANAGER';reason='Finance-manager approval required (amount > $10,000)';flags.append('HIGH_VALUE')
    if manager and 'HIGH_VALUE' not in flags: flags.append('HIGH_VALUE')
    if manager and status!='REVIEW_MANAGER': reason+='; finance-manager approval also required (>$10,000)'
    return {**{k:inv[k] for k in ['team_id','invoice_id','supplier','invoice_ref','po_id']},
            'amount_usd':amount, 'bank_changed':'YES' if bank_changed else 'NO',
            'status':status,'reason':reason,'control_flags':'|'.join(flags) or 'NONE',
            'manager_approval_required':manager,'human_approval_required':True,
            'payment_authorized':False,'ai_can_override_status':False,
            'sources':['data/purchase_orders.csv','data/posted_invoice_history.csv','data/invoices_8.csv']}

def invoice_results():
    invoices=load('invoices_8.csv'); rs=[triage(r) for r in invoices]
    return {'case_count':len(rs),'status_counts':dict(collections.Counter(r['status'] for r in rs)),
            'results':rs,'payment_authorized':False}

def check():
    expected=load('invoice_expected.csv'); actual=invoice_results()['results']; mismatch=[]
    for exp,a in zip(expected,actual):
        if exp['invoice_id']!=a['invoice_id'] or exp['expected_status']!=a['status']:
            mismatch.append({'expected':exp,'actual':a['status']})
    return {'passed':len(expected)==len(actual) and not mismatch,'case_count':len(actual),'mismatches':mismatch,
            'no_payment_authorized':all(r['payment_authorized'] is False for r in actual)}

def main():
    p=argparse.ArgumentParser(description='Synthetic read-only finance toolkit')
    p.add_argument('action',choices=['metrics','invoices','check','one','memo-data'])
    p.add_argument('--invoice-id',help='For one invoice')
    p.add_argument('--output',help='Optional JSON file, saved only inside supplied lab folder')
    a=p.parse_args()
    if a.action=='metrics': result=financial_metrics()
    elif a.action=='invoices': result=invoice_results()
    elif a.action=='check': result=check()
    elif a.action=='memo-data': result={'financial':financial_metrics(),'invoices':invoice_results()}
    else:
        matches=[r for r in invoice_results()['results'] if r['invoice_id']==a.invoice_id]
        if not matches: p.error('Invoice not found. Try INV-203')
        result=matches[0]
    payload=json.dumps(result,indent=2,ensure_ascii=False)
    if a.output:
        target=pathlib.Path(a.output).expanduser().resolve()
        if not target.is_relative_to(BASE): p.error('Output must be inside the provided Hermes lab folder')
        target.parent.mkdir(parents=True,exist_ok=True);target.write_text(payload+'\n',encoding='utf-8')
        print(f'Wrote synthetic output to: {target}')
    else: print(payload)
if __name__=='__main__': main()
