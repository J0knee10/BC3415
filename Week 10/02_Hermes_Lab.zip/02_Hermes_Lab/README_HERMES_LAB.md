# Hermes Agent — Meridian finance analyst lab (150 minutes)

This is a standalone, synthetic finance lab kit designed to complement the n8n invoice workflow lab.

## File map
- `data/meridian_financials.csv`: financial statements, USD **thousands**.
- `data/invoices_8.csv`: 8 synthetic invoices, amounts in full USD, **same cases as the n8n lab**.
- `data/purchase_orders.csv`: fixed PO fixture (not a live system).
- `data/posted_invoice_history.csv`: fixed historical-duplicate fixture.
- `data/company_policy.csv`: business rule priority.
- `data/invoice_expected.csv`: instructor reference classifications; students may use it only at verification stage.
- `scripts/meridian_finance.py`: deterministic read-only finance tool; Python standard library only.
- `scripts/test_meridian_finance.py`: pytest unit tests (requires pytest; optional).
- `skill_template/meridian-finance-analyst/SKILL.md`: copy into Hermes profile-local `~/.hermes/skills/education/meridian-finance-analyst/SKILL.md` to teach skill reuse.
- `prompts/`: copyable prompts; `evaluation/`: results log.

## Test the business toolkit BEFORE connecting an LLM
```bash
cd 02_Hermes_Lab
python3 scripts/meridian_finance.py metrics
python3 scripts/meridian_finance.py invoices
python3 scripts/meridian_finance.py check
# Optional if pytest is available:
python3 -m pytest scripts/test_meridian_finance.py -q
```

Expected: 8 invoices, check.passed=true, no_payment_authorized=true. The tests are validated locally. The full Hermes app/model integration still requires your own VM and credentials.

## Hermes install
Use the official guide: https://hermes-agent.nousresearch.com/docs/getting-started/quickstart/
Install only on a **disposable, non-privileged class VM**, with no host home-directory mounts, no real business data, and no access to the existing n8n secrets.

Official Linux/macOS/WSL CLI install (requires user approval of remote installer under institution policy):
```bash
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
source ~/.bashrc
hermes setup
hermes --version
hermes chat --oneshot -q "Reply with the words HERMES READY."
```
Set up an eligible provider/model first; a successful install does not include free inference. Use `hermes model` to select a provider and check costs/quotas; model availability changes. In class prefer `hermes chat --toolsets terminal,file,skills --oneshot -q "..."` with the lab-root working directory. Do not connect Telegram or external credentials for this workshop.

## Skills
```bash
mkdir -p ~/.hermes/skills/education/meridian-finance-analyst
cp skill_template/meridian-finance-analyst/SKILL.md ~/.hermes/skills/education/meridian-finance-analyst/SKILL.md
hermes skills
```
Start a new chat/session so the new skill is indexed; ask to run the `meridian-finance-analyst` skill by name and verify the actual tool trace. The skill is instructions, not executable software or a security boundary.

## Limits
This kit contains a **tested deterministic Python toolkit**, a teaching skill, synthetic data, prompts and scoring forms. It is **not** a verified end-to-end Hermes deployment or a production-grade finance application. The Hermes live test must be performed during instructor rehearsal in the designated VM.
